<?php
/*
Plugin Name: Arnold Button Shortcode
Description: Adds a shortcode to create buttons using the Arnold WordPress theme
Version: 1.0
Author: Nxvermore
*/

function arnold_button_shortcode( $atts, $content = null ) {
	$atts = shortcode_atts( array(
		'url' => '',
		'color' => 'primary',
		'size' => 'normal',
	), $atts, 'button' );

	return '<a href="' . esc_url( $atts['url'] ) . '" class="button ' . esc_attr( $atts['color'] ) . ' ' . esc_attr( $atts['size'] ) . '">' . $content . '</a>';
}
add_shortcode( 'button', 'arnold_button_shortcode' );